"""Browser end-to-end flow (Playwright for Python). Needs API on :4000 and `vite preview` on :4173 (see docs/STATUS.md)."""
import re, time, json, datetime
from playwright.sync_api import sync_playwright, expect

BASE='http://localhost:4173'
EMAIL='e2e'+str(int(time.time()))+'@example.com'
errors=[]
def run():
    with sync_playwright() as pw:
        b=pw.chromium.launch()
        ctx=b.new_context(viewport={'width':1280,'height':820}, device_scale_factor=1, timezone_id='Africa/Nairobi', permissions=[])
        p=ctx.new_page()
        p.on('console', lambda m: errors.append(f'console.{m.type}: {m.text}') if m.type=='error' else None)
        p.on('pageerror', lambda e: errors.append(f'pageerror: {e}'))
        p.goto(BASE+'/')
        # intro shows on first visit
        expect(p.get_by_role('dialog', name='Welcome')).to_be_visible()
        p.wait_for_timeout(1800); p.screenshot(path='/home/claude/scratch/shots/01-intro.png')
        p.get_by_role('dialog', name='Welcome').click()
        expect(p.get_by_text('Welcome back')).to_be_visible(timeout=5000)
        p.screenshot(path='/home/claude/scratch/shots/02-login.png')
        # register
        p.get_by_role('link', name='Create account').click()
        p.get_by_label('Name', exact=True).fill('Legendary Smiley')
        p.get_by_label('Email').fill(EMAIL)
        p.get_by_label('Password').fill('e2e pass 12345')
        p.get_by_role('button', name='Create account').click()
        expect(p.get_by_text('Good ', exact=False).first).to_be_visible(timeout=10000)
        print('registered+dashboard OK, url', p.url)
        # create an activity starting 1 min ago, ending in 59 min (so it is "now") via planner UI
        now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=3)))
        s=(now-datetime.timedelta(minutes=1)).strftime('%H:%M'); e=(now+datetime.timedelta(minutes=59)).strftime('%H:%M')
        p.get_by_role('link', name='+ Plan activity').click()
        p.get_by_role('button', name='+ New').click()
        p.get_by_role('textbox', name='Activity').fill('Study Mathematics')
        p.locator('input[type=time]').nth(0).fill(s); p.locator('input[type=time]').nth(1).fill(e)
        p.screenshot(path='/home/claude/scratch/shots/03-form.png')
        p.get_by_role('button', name='Add activity').click()
        expect(p.get_by_text('Study Mathematics').first).to_be_visible(timeout=8000)
        # overlapping second activity -> overlap warning, nothing moved
        p.get_by_role('button', name='+ New').click()
        p.get_by_role('textbox', name='Activity').fill('Overlapper')
        p.locator('input[type=time]').nth(0).fill(s); p.locator('input[type=time]').nth(1).fill(e)
        p.get_by_role('button', name='Add activity').click()
        expect(p.get_by_text('overlap').first).to_be_visible(timeout=8000)
        p.screenshot(path='/home/claude/scratch/shots/04-planner.png')
        # dashboard: check in, live timer, pause/resume
        p.get_by_role('link', name='Today').first.click()
        expect(p.get_by_role('button', name='Check in')).to_be_visible(timeout=8000)
        p.get_by_role('button', name='Check in').click()
        expect(p.get_by_role('button', name='Check out')).to_be_visible(timeout=8000)
        p.wait_for_timeout(2500)
        p.screenshot(path='/home/claude/scratch/shots/05-dashboard-running.png')
        p.get_by_role('button', name='Pause').click()
        expect(p.get_by_role('button', name='Resume')).to_be_visible(timeout=8000)
        p.get_by_role('button', name='Resume').click()
        expect(p.get_by_role('button', name='Pause')).to_be_visible(timeout=8000)
        # OFFLINE: pause while offline -> queued with real timestamp, then sync on reconnect
        ctx.set_offline(True)
        p.evaluate("window.dispatchEvent(new Event('offline'))")
        expect(p.get_by_text('You are offline')).to_be_visible(timeout=5000)
        p.get_by_role('button', name='Pause').click()
        expect(p.get_by_text('Saved offline').first).to_be_visible(timeout=5000)
        expect(p.get_by_role('button', name='Resume')).to_be_visible()
        p.screenshot(path='/home/claude/scratch/shots/06-offline.png')
        queued=p.evaluate("""() => new Promise(r => { const q = indexedDB.open('cymor-todo',1); q.onsuccess = () => { const g = q.result.transaction('queue').objectStore('queue').getAll(); g.onsuccess = () => r(g.result) } })""")
        print('queued in IndexedDB:', json.dumps(queued))
        ctx.set_offline(False)
        p.evaluate("window.dispatchEvent(new Event('online'))")
        expect(p.get_by_text('Synced 1 offline action').first).to_be_visible(timeout=10000)
        print('offline queue synced OK')
        # check out
        p.get_by_role('button', name='Resume').click()
        p.get_by_role('button', name='Check out').click()
        p.wait_for_timeout(1200)
        p.screenshot(path='/home/claude/scratch/shots/07-after-checkout.png')
        # reminders: create Drink Water template and see preview
        p.get_by_role('link', name='Reminders').first.click()
        p.get_by_role('button', name='+ New reminder').click()
        expect(p.get_by_text('Next firings')).to_be_visible()
        p.wait_for_timeout(900)
        p.screenshot(path='/home/claude/scratch/shots/08-reminder-form.png')
        p.get_by_role('button', name='Create reminder').click()
        expect(p.get_by_text('Drink Water').first).to_be_visible(timeout=8000)
        expect(p.get_by_text('Every 2h, 08:00–20:00')).to_be_visible()
        p.screenshot(path='/home/claude/scratch/shots/09-reminders.png')
        # analytics
        p.get_by_role('link', name='Analytics').first.click()
        expect(p.get_by_text('Completion')).to_be_visible(timeout=8000)
        p.screenshot(path='/home/claude/scratch/shots/10-analytics.png')
        # notifications centre
        p.get_by_role('link', name='Alerts').first.click()
        expect(p.get_by_text('System check')).to_be_visible(timeout=8000)
        expect(p.get_by_text('Background worker has never reported in', exact=False)).to_be_visible()
        p.screenshot(path='/home/claude/scratch/shots/11-notifications.png')
        # growth + settings
        p.get_by_role('link', name='Growth').first.click()
        p.get_by_placeholder('New habit, e.g. Read 20 pages').fill('Read'); p.get_by_role('button', name='Add').click()
        expect(p.get_by_text('Read', exact=True).first).to_be_visible(timeout=8000)
        p.get_by_role('link', name='Settings').first.click()
        expect(p.get_by_role('heading', name='Profile')).to_be_visible(timeout=8000)
        p.get_by_label('Theme').first if False else None
        p.screenshot(path='/home/claude/scratch/shots/12-settings.png', full_page=True)
        # service worker registered (prod build)
        p.wait_for_timeout(1000)
        sw=p.evaluate("navigator.serviceWorker.getRegistration().then(r => !!r && !!(r.active||r.installing||r.waiting))")
        print('service worker registered:', sw)
        # mobile view
        m=b.new_context(viewport={'width':390,'height':800}, device_scale_factor=2, timezone_id='Africa/Nairobi', is_mobile=True, has_touch=True)
        mp=m.new_page()
        mp.goto(BASE+'/login'); mp.evaluate("localStorage.setItem('cymor.intro.v1','1')"); mp.reload()
        mp.get_by_label('Email').fill(EMAIL); mp.get_by_label('Password').fill('e2e pass 12345'); mp.get_by_role('button', name='Sign in').click()
        expect(mp.get_by_text('Good ', exact=False).first).to_be_visible(timeout=10000)
        mp.wait_for_timeout(600); mp.screenshot(path='/home/claude/scratch/shots/13-mobile-dashboard.png')
        ov=mp.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth")
        print('mobile horizontal overflow:', ov)
        b.close()
try:
    run(); print('E2E PASSED')
except Exception as ex:
    print('E2E FAILED:', str(ex)[:600])
print('browser errors:', errors[:8])
